# FE case

## Instructions
There are several issues on the code that needs to be fixed. You have 3 hours to complete the test, after completing the test, zip it and reply the email that you recieved the test from. 
It is NOT allowed to add any 3rd party script or styling to complete the test.

## Assignment
1. Implement a "spacify" function on String, that returns a string with spaces between all characters only for use on h1
2. Add content from headerText variable to h1 item
3. Set random backgroundColor on each article
4. Make articles display in 5 columns. All content must be visible and each rows items must have equal heights.
5. Adjust columns on smaller screens => 2 columns on mobile screens, and 3 on tablet.
6. Create a hover effect that looks like the attached gif-animation.
7. Fix the bug in the code (open main.js - look for "Assignment 7: Fix the code")
8. Fix the bug in the code (open main.js - look for "Assignment 8: Fix the code")
