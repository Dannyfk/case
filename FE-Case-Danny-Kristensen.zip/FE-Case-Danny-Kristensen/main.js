	//run when dom is loaded
	document.addEventListener("DOMContentLoaded", function(event) { 
		//select the h1 tag and set it to the headertext. 
		document.querySelector("h1").innerHTML = headerText;
		//call the color article function
		colorArticles();

	});
	
	//add spacify function to strang class that inputs spaces between all characters in the string
	String.prototype.spacify = function (){ 
		var inputSpaces = this.split("").join(" ")
		return inputSpaces;
	}
	
	  //selects all articles and colors them
	  function colorArticles(){
		var articles = document.querySelectorAll("article"); 
		for (i = 0; i < articles.length; i++) { 
			articles[i].style.backgroundColor = randomColor();
		}
	  }
	
	  //returns random hex value
	function randomColor(){
		return '#'+(0x1000000+(Math.random())*0xffffff).toString(16).substr(1,6);
	}



var headerText = 'hello world'.spacify();


// Assignment 7: Fix the code
// the buttons should alert the number written on them - currently they all alert 5
for (var i=0, btn; i<5; i++) {
	btn = document.createElement("button");
	btn.innerHTML = "Button #" + i;
	btn.value = i;
	btn.onclick = function () {
		alert(this.value);
	};
	document.body.appendChild(btn);
}

// Assignment 8: Fix the code
var Friends = (function() {
	function Friends() {
		var i = 0;	
		var ival = setInterval(function() {
			console.log(this.Friends.prototype.friends[i]);
			i++;
			if(i === this.Friends.prototype.friends.length) {
				clearInterval(ival);
			}
		}, 1000);
	}
	Friends.prototype.friends = ['Mikkel', 'Jens', 'Filip'];
	
	return Friends;
	
})();

var f = new Friends();
var f2 = new Friends();

/* it should log:
Mikkel
Mikkel
Jens
Jens
Filip
Filip
*/



